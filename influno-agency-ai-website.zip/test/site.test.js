const {test}=require('node:test');const assert=require('node:assert');const fs=require('fs');const path=require('path');
const site=path.join(__dirname,'..','site');const html=fs.readFileSync(path.join(site,'index.html'),'utf8');
test('core content',()=>{
  assert.match(html,/<title>Influno Agency AI/);
  assert.match(html,/name="viewport" content="width=device-width/);
  for(const s of ['₹999','wa.me/919405581203','tel:+919405581203','instagram.com/influnoagency','yashmargepawar2009@gmail.com','© 2026 Influno Agency AI','WhatsApp Integration','AI Chatbot','Google Business Profile','SEO','Call','Design','Launch','Grow','og:image'])assert.ok(html.includes(s),'missing '+s);
});
test('no fake claims or placeholders',()=>{
  for(const s of ['+128%','200+','5-star','5-Star','lorem','TODO','__WA__','12+ businesses'])assert.ok(!html.includes(s),'found '+s);
  const wa=[...html.matchAll(/wa\.me\/919405581203\?text=([^"]+)/g)].map(m=>decodeURIComponent(m[1]));
  assert.ok(wa.length>0);for(const t of wa)assert.ok(!/[\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}]/u.test(t),'emoji in prefill');
});
test('local assets exist',()=>{
  const refs=[...html.matchAll(/(?:src|href)="([^"#:]+)"/g)].map(m=>m[1]).filter(r=>!r.startsWith('http')&&!r.startsWith('mailto')&&!r.startsWith('tel'));
  for(const r of refs)assert.ok(fs.existsSync(path.join(site,r)),'missing asset '+r);
  const css=fs.readFileSync(path.join(site,'styles.css'),'utf8');
  for(const m of css.matchAll(/url\((assets\/[^)]+)\)/g))assert.ok(fs.existsSync(path.join(site,m[1])),'missing '+m[1]);
  assert.ok(fs.existsSync(path.join(site,'og.png')));
});
