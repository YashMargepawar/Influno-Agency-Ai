(()=>{
const d=document,root=d.documentElement,body=d.body;root.classList.remove('no-js');
const reduce=matchMedia('(prefers-reduced-motion: reduce)').matches;
const fine=matchMedia('(hover:hover) and (pointer:fine)').matches;
const $=(s,c=d)=>c.querySelector(s),$$=(s,c=d)=>[...c.querySelectorAll(s)];

/* split headings into words */
$$('.split').forEach(el=>{
  const walk=n=>{[...n.childNodes].forEach(c=>{
    if(c.nodeType===3){const f=d.createDocumentFragment();c.textContent.split(/(\s+)/).forEach(t=>{if(!t)return;if(/^\s+$/.test(t)){f.append(t);return}const w=d.createElement('span');w.className='w';const i=d.createElement('span');i.textContent=t;w.append(i);f.append(w)});c.replaceWith(f)}
    else if(c.nodeType===1&&c.tagName!=='BR')walk(c)})};
  walk(el);
  $$('.w>span',el).forEach((s,i)=>s.style.transitionDelay=(i*0.05)+'s');
});

/* scrub statement into words */
const scrub=$('#scrub');let sws=[];
if(scrub){const hl=['digital','technology','fayda','easy.'];scrub.innerHTML=scrub.textContent.trim().split(/\s+/).map(w=>`<span class="sw${hl.some(h=>w.toLowerCase().startsWith(h))?' hl':''}">${w}</span>`).join(' ');sws=$$('.sw',scrub)}

/* loader */
const done=()=>body.classList.add('loaded');
if(reduce)done();else{window.addEventListener('load',()=>setTimeout(done,700));setTimeout(done,2200)}

/* reveal on scroll */
const io=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){e.target.classList.add('in');io.unobserve(e.target)}}),{threshold:.15,rootMargin:'0px 0px -8% 0px'});
$$('.reveal-up:not(.hero .reveal-up),.split,.mega').forEach(el=>io.observe(el));
const cio=new IntersectionObserver(es=>{if(es[0].isIntersecting){$$('.card').forEach((c,i)=>setTimeout(()=>c.classList.add('in'),i*180));cio.disconnect()}},{threshold:.05});cio.observe($('#hscroll'));

/* nav */
const nav=$('.nav'),wa=$('.wa-float');let lastY=0;

/* horizontal services */
const hs=$('#hscroll'),track=$('#htrack'),hbar=$('#hbar');let hDist=0;
const setupH=()=>{
  if(reduce){hs.classList.remove('pinned');hs.style.height='';track.style.transform='';return}
  hs.classList.add('pinned');
  hDist=Math.max(0,track.scrollWidth-innerWidth);
  hs.style.height=(hDist+innerHeight)+'px';
};

/* timeline */
const tl=$('#timeline'),tlfill=$('#tlfill'),steps=$$('.step');
const vertical=()=>innerWidth<=760;

const clamp=(v,a,b)=>Math.min(b,Math.max(a,v));
let ticking=false;
const onScroll=()=>{
  const y=scrollY,vh=innerHeight;
  nav.classList.toggle('scrolled',y>40);
  nav.classList.toggle('hide',y>lastY&&y>600);lastY=y;
  wa.classList.toggle('show',y>vh*.7);
  if(!reduce){
    if(hDist>0){const r=hs.getBoundingClientRect();const p=clamp(-r.top/hDist,0,1);track.style.transform=`translate3d(${-p*hDist}px,0,0)`;hbar.style.transform=`scaleX(${p})`}
    if(sws.length){const r=scrub.getBoundingClientRect();const p=clamp((vh*.85-r.top)/(r.height+vh*.35),0,1);const n=Math.round(p*sws.length);sws.forEach((s,i)=>s.classList.toggle('on',i<n))}
    if(tl){const r=tl.getBoundingClientRect();const p=clamp((vh*.7-r.top)/(r.height),0,1);tlfill.style.transform=vertical()?`scaleY(${p})`:`scaleX(${p})`;steps.forEach((s,i)=>s.classList.toggle('on',p>=(vertical()?i/steps.length+.02:i/(steps.length-1)-.04)))}
  }
  ticking=false;
};
addEventListener('scroll',()=>{if(!ticking){ticking=true;requestAnimationFrame(onScroll)}},{passive:true});
let rz;addEventListener('resize',()=>{clearTimeout(rz);rz=setTimeout(()=>{setupH();sizeCanvas();onScroll()},150)});
setupH();onScroll();
d.fonts&&d.fonts.ready.then(()=>{setupH();onScroll()});

/* cursor blob */
if(fine&&!reduce){
  const c=$('.cursor');let mx=innerWidth/2,my=innerHeight/2,cx=mx,cy=my;
  addEventListener('pointermove',e=>{mx=e.clientX;my=e.clientY;body.classList.add('has-cursor')},{passive:true});
  d.addEventListener('pointerleave',()=>body.classList.remove('has-cursor'));
  (function loop(){cx+=(mx-cx)*.12;cy+=(my-cy)*.12;c.style.transform=`translate3d(${cx}px,${cy}px,0)`;requestAnimationFrame(loop)})();
  /* magnetic */
  $$('.magnetic').forEach(b=>{
    b.addEventListener('pointermove',e=>{const r=b.getBoundingClientRect();b.style.setProperty('--mx',((e.clientX-r.left-r.width/2)*.3)+'px');b.style.setProperty('--my',((e.clientY-r.top-r.height/2)*.4)+'px')});
    b.addEventListener('pointerleave',()=>{b.style.setProperty('--mx','0px');b.style.setProperty('--my','0px')});
  });
  /* tilt */
  $$('.tilt').forEach(t=>{
    t.addEventListener('pointermove',e=>{const r=t.getBoundingClientRect();const x=(e.clientX-r.left)/r.width,y=(e.clientY-r.top)/r.height;t.style.transform=`perspective(900px) rotateX(${(.5-y)*10}deg) rotateY(${(x-.5)*12}deg) translateZ(0)`;t.style.setProperty('--gx',x*100+'%');t.style.setProperty('--gy',y*100+'%')});
    t.addEventListener('pointerleave',()=>{t.style.transform=''});
  });
}

/* FAQ: one open at a time */
$$('.faq details').forEach(dt=>dt.addEventListener('toggle',()=>{if(dt.open)$$('.faq details').forEach(o=>{if(o!==dt)o.open=false})}));

/* hero particle mesh */
const cv=$('#mesh'),ctx=cv&&cv.getContext('2d');let W=0,H=0,DPR=1,pts=[],pointer={x:-9999,y:-9999},heroVisible=true;
function sizeCanvas(){if(!ctx)return;DPR=Math.min(devicePixelRatio||1,1.75);W=cv.clientWidth;H=cv.clientHeight;cv.width=W*DPR;cv.height=H*DPR;ctx.setTransform(DPR,0,0,DPR,0,0);
  const n=Math.round(clamp(W*H/16000,28,90));pts=Array.from({length:n},()=>({x:Math.random()*W,y:Math.random()*H,vx:(Math.random()-.5)*.35,vy:(Math.random()-.5)*.35,r:Math.random()*1.6+.6}));}
sizeCanvas();
if(ctx){
  cv.parentElement.addEventListener('pointermove',e=>{const r=cv.getBoundingClientRect();pointer.x=e.clientX-r.left;pointer.y=e.clientY-r.top},{passive:true});
  cv.parentElement.addEventListener('pointerleave',()=>{pointer.x=pointer.y=-9999});
  new IntersectionObserver(es=>{heroVisible=es[0].isIntersecting},{threshold:0}).observe(cv);
  const L=W<700?95:140;
  const draw=()=>{
    ctx.clearRect(0,0,W,H);
    for(const p of pts){
      if(!reduce){p.x+=p.vx;p.y+=p.vy;if(p.x<0||p.x>W)p.vx*=-1;if(p.y<0||p.y>H)p.vy*=-1;
        const dx=p.x-pointer.x,dy=p.y-pointer.y,dd=dx*dx+dy*dy;if(dd<14400){const f=(14400-dd)/14400*1.2;p.x+=dx/Math.sqrt(dd||1)*f;p.y+=dy/Math.sqrt(dd||1)*f}}
    }
    for(let i=0;i<pts.length;i++){const a=pts[i];
      for(let j=i+1;j<pts.length;j++){const b=pts[j],dx=a.x-b.x,dy=a.y-b.y,dist=dx*dx+dy*dy;
        if(dist<L*L){ctx.strokeStyle=`rgba(180,255,31,${(1-Math.sqrt(dist)/L)*.28})`;ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(a.x,a.y);ctx.lineTo(b.x,b.y);ctx.stroke()}}
      ctx.fillStyle='rgba(200,255,90,.85)';ctx.beginPath();ctx.arc(a.x,a.y,a.r,0,6.283);ctx.fill()}
  };
  if(reduce)draw();else (function loop(){if(heroVisible&&!d.hidden)draw();requestAnimationFrame(loop)})();
}
})();
